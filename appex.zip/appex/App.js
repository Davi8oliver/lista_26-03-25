import { StatusBar } from 'expo-status-bar';   

 

import { useState } from 'react';   

 

import { StyleSheet, Text, TouchableOpacity, View } from 'react-native';   

 

import { TextInput } from 'react-native-web';   

 

export default function App() {   

 

  const [ce, setCe]=useState();   

 

  const [fa, setFa]=useState();   

 

  const [resul, setResul]=useState();   

 

  const decisao = (temp) =>{   

 

    const c = parseFloat(ce);   

    const f = parseFloat(fa);   

 

    switch(temp) { 

      case 'cel': 

        setResul((f - 32) / 1.8 ); 

      break; 

      case 'far': 

        setResul((c * 1.8) + 32);   

      break; 

      default: 

      break; 

    } 

 

  }   

 

  return (   

 

    <View style={styles.container}>  

      <Text>Celsius ou Fahrenheit?</Text> 

      <TextInput   

        placeholder= "Quantos Celsius"   

        value={ce}   

        onChangeText={(Text) => setCe(Text)}   

      />   

      <TextInput   

        placeholder= "Quantos Fahrenheit"   

        value={fa}   

        onChangeText={(Text) => setFa(Text)}   

      />   

      <TouchableOpacity style={styles.button1} onPress={() => 

        decisao('cel')}> 

        <Text>Celsius</Text> 

      </TouchableOpacity> 

      <TouchableOpacity style={styles.button2}  onPress={() => 

        decisao('far')}> 

        <Text>Fahrenheit</Text> 

      </TouchableOpacity> 

      <Text>{resul}</Text> 

      <StatusBar style="auto" />   

    </View>   

 

);}  

 

const styles = StyleSheet.create({  

 

  container: {   

    flex: 1,  

    backgroundColor: '#fff',   

    alignItems: 'center',   

    justifyContent: 'center',   

  },   

 

  input: {   

    borderWidth: 1,   

    padding: 5, 

  },  

 

  title: {  

    fontSize: 24,  

    fontWeight: 'bold',  

    color: '#333',   

    marginBottom: 20,   

  },   

   

    result: {   

    fontSize: 20, fontWeight: 'bold',   

    color: '#333',   

  }, 

    button1: { 

    backgroundColor: '#8BAE70', padding: 10, borderRadius: 5, 

    marginHorizontal: 5, 

  }, 

    button2: { 

    backgroundColor: '#1CAF50', padding: 10, borderRadius: 5, 

    marginHorizontal: 5, 

  } 

     

}); 